package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;

public class ShieldShunt extends BaseHullMod {

	//public static float EMP_RESISTANCE = 50f;
	//public static float VENT_RATE_BONUS = 50f;
	//public static float ARMOR_BONUS = 15f;

	public static float FLUX_COST_MULT = 1.2f;
	public static float FIRERATE_BONUS = 40f;
	public static float SMOD_ARMOR_BONUS = 20f;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		boolean sMod = isSMod(stats);
		stats.getBallisticRoFMult().modifyMult(id, 1f + FIRERATE_BONUS * 0.01f);
		stats.getEnergyRoFMult().modifyMult(id, 1f + FIRERATE_BONUS * 0.01f);

		stats.getEnergyWeaponFluxCostMod().modifyMult(id, FLUX_COST_MULT);
		stats.getBallisticWeaponFluxCostMod().modifyMult(id, FLUX_COST_MULT);
		
		if (sMod) {
			stats.getArmorBonus().modifyPercent(id, SMOD_ARMOR_BONUS);
		}
	}
	
//	@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		ship.setShield(ShieldType.NONE, 0f, 1f, 1f);
	}


	public String getDescriptionParam(int index, HullSize hullSize) {
		//if (index == 0) return "" + (int) EMP_RESISTANCE + "%";
		//if (index == 0) return "" + (int) VENT_RATE_BONUS + "%";
		//if (index == 0) return "" + (int) ARMOR_BONUS + "%";
		if (index == 0) return "" + (int) FIRERATE_BONUS + "%";
		if (index == 1) return "" + (int)Math.round((FLUX_COST_MULT - 1f) * 100f) + "%";
		return null;
	}

	public boolean isApplicableToShip(ShipAPI ship) {
		if (ship.getVariant().getHullSpec().getShieldType() == ShieldType.NONE && 
				!ship.getVariant().hasHullMod("frontshield")) return false;
		if (ship.getVariant().hasHullMod(HullMods.SHIELD_SHUNT)) return true;
		if (ship.getVariant().hasHullMod(HullMods.MAKESHIFT_GENERATOR)) return false;
		return ship != null && ship.getShield() != null;
	}
	
	public String getUnapplicableReason(ShipAPI ship) {
		if (ship.getVariant().hasHullMod(HullMods.MAKESHIFT_GENERATOR)) {
			return "Incompatible with Makeshift Shield Generator";
		}
		return "Ship has no shields";
	}
	
	public String getSModDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) SMOD_ARMOR_BONUS + "%";
		return null;
	}
	
	public boolean hasSModEffect() {
		// breaks something if it can be built in - I think something to do with preconditions for
		// shield-related hullmods; not 100% sure on details but sure there was a problem -am
		// Ah! The issue was being able to build it in and then some kind of order-of-operations with
		// Makeshift Shield Generator. Made those incompatible. -am
		return true;
	}
	
}









